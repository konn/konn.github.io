=begin

= WereWolf - �ėp�l�T�G���W��
  
  version: WereWolf-3.0.0b3 (2006-04-14T00:13:39+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

module WereWolf
  class StandardProfs

    def initialize
      @profs = Hash.new(nil)
      @profs[:vil] = false
      @profs[:fortune] = true
      @profs[:wolf] = true
      @profs[:guard] = true
      @profs[:medium] = true
      @profs[:lunat] = false
      @profdic = {}
      @guarded = nil
      @win_check = [:wolf, :vil]
      @wolf_attacked = nil
      @prof_prio = [:fortune, :guard, :wolf, :medium]
      setup if respond_to?(:setup)
    end
    
    def set_prof(from, to)
      if @profs[from.prof] && from != to
        @profdic[from] = to
        return true
      end
    end
    
    def use_prof(sender)
      results = {}
      @persons = sender.persons
      @hanged = sender.hanged
      @progress = sender.progress
      @prof_prio.each{|item|
        if respond_to?("#{item}_use")
          @alivers = sender.alivers
          results[item] = __send__("#{item}_use")
        end
      }
      @profdic = {}
      results
    end
    
    def winner(sender)
      @persons = sender.persons
      @progress = sender.progress
      @alivers = sender.alivers
      @hanged = sender.hanged
      @win_check.each{|item|
        if respond_to?("#{item}_win?")
          if __send__("#{item}_win?")
            return item 
          end
        end
      }
      nil
    end
    
    def wolf_win?
      wolves = @alivers.select{|p| p.prof == :wolf}
      wolves.size >= @alivers.size / 2.0
    end
    
    def vil_win?
      wolves = @alivers.select{|p| p.prof == :wolf}
      wolves.empty?
    end
    
    def wolf_use
      @wolf_attacked = nil
      wolves = @alivers.select{|p| p.prof == :wolf}
      return nil if wolves.empty?
      attacks = []
      wolves.each {|wo|
        attacks.push @profdic[wo]
      }
      attacks.compact!
      attacks.uniq!
      return nil if attacks.empty?
      attack = attacks[rand(attacks.size)]
      unless attack == @guarded && attack.alived?
        attack.kill
        @wolf_attacked = attack
        return attack
      else
        return false
      end
    end
    
    def fortune_use
      results = {}
      fortunes = @alivers.select{|p| p.prof == :fortune}
      fortunes.each {|fort|
        results[fort] = [@profdic[fort], @profdic[fort].prof == :wolf] if @profdic[fort]
      }
      results
    end
    
    def medium_use
      if @hanged
        return @hanged.prof == :wolf
      end
    end
    
    def prof_prio
      return @prof_prio
    end
    
    def prof_prio=(other)
      if Enumerable === other
        prof_prio = other
      else
        raise "prof_prio must be Enumerable"
      end
    end

  end

=begin
= HamsterProfs
=end

  class HamsterProfs < StandardProfs

    def setup
      @win_check.unshift(:hamster)
    end
    
    def wolf_use
      @wolf_attacked = nil
      wolves = @alivers.select{|p| p.prof == :wolf}
      return nil if wolves.empty?
      attacks = []
      wolves.each {|wo|
        attacks.push @profdic[wo]
      }
      attacks.compact!
      attacks.uniq!
      return nil if attacks.empty?
      attack = attacks[rand(attacks.size)]
      unless attack == @guarded || attack.prof == :hamster
        attack.kill
        @wolf_attacked = attack
        return attack
      else
        return false
      end
    end
    
    def fortune_use
      results = {}
      fortunes = @alivers.select{|p| p.prof == :fortune}
      fortunes.each {|fort|
        if f = @profdic[fort]
          if f.prof == :hamster
            f.kill
            results[fort] = [f, nil]
          else
            results[fort] = [f, f.prof == :wolf] 
          end
        end
      }
      results
    end
    
    def hamster_win?
      r = (vil_win? || wolf_win?) && @alivers.any?{|a| a.prof == :hamster}
    end

  end

=begin
= PossessionProfs
=end

  class PossessionProfs < WereWolf::StandardProfs
    
    def initialize(range=1)
      super()
      @range = range
    end
    
    def wolf_use
      if @hanged && @profdic[@hanged]
        if @hanged.prof == :wolf && @range === @progress
          @profdic[@hanged].prof = :wolf if @profdic[@hanged]
          return [:hyoui, @profdic[@hanged]]
        end
      end
      super
    end
  
  end

end

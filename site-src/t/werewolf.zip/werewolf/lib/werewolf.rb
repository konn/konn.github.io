$LOAD_PATH.shift "./lib"
require "person.rb"
require "profs.rb"
require "village.rb"
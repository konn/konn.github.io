=begin

= WWBot - Jinroh Bot for IRC (powered by WereWolf)
  
  version: WWBot-1.0.0b1 2006-04-14T00:10:11+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

$LOAD_PATH.unshift("../../")
require "ircb.rb"
require "village.rb"
require "thread"

$KCODE = "U"

class WWBot < IRCB::SimpleBot

  IDLE = -2
  ARRANGE = -1
  WAIT = 0
  STARTED = 1
  
  CHARS = %W(パメラ カタリナ リーザ オットー ヴァルター ヨアヒム アルビン ディーター ニコラス トーマス  ヤコブ ジムゾン ペーター モーリッツ レジーナ)
  PROFS =  {1 => [:vil], 2 => [:vil, :vil], 3 => [:vil, :vil, :wolf], 
            4 => [:vil, :vil, :wolf, :fortune], 
            5 => [:vil, :vil, :medium, :wolf, :fortune], 
            6 => [:vil, :vil, :medium, :wolf, :wolf, :fortune],
            7 => [:vil, :guard, :meduim, :wolf, :wolf, :fortune, :lunat],
            8 => [:vil, :vil, :guard, :meduim, :wolf, :wolf, :fortune, :lunat],
            9 => [:vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            10 => [:vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            11 => [:vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            12 => [:vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat], 
            13 => [:vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            14 => [:vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            15=>[:vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            16=>[:vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            }
  PNAME = {:vil, "村人", :wolf, "人狼", :medium, "霊能者", :fortune, "占い師", :guard, "狩人", :lunat, "狂人"}
  
  def initialize(*args)
    super
    @progress = IDLE
    @date = -1
    @villager = []
    @whois = {}
    @initialized = true
    @talk = false
    @t = Thread.new{}
    @capa = 16
    @mutex = Mutex.new
    @gerd = true
    @capamax = 16
    @capamin = 3
    @profclass = WereWolf::StandardProfs
    @period = 60
  end
  
  def on_privmsg(prefix, ch, msg)
    if ch == @nick
      case @progress
      when WAIT
        if msg =~ /^(entry|エントリ(?:ー)?|suntry|サントリー)$/i
          user = prefix.user
          unless @villager.any?{|a| a[0] == user}
            @mutex.synchronize {
              unless @villager.size >= @capa
                char = @chars.slice!(rand(@chars.size))
                @villager.push [user, char]
                notice(prefix.nick, "エントリー受け付けました。あなたは#{char}です。")
                notice(@mainch, "#{char}がエントリーしました。残り#{@capa - @villager.size}人です。")
              end
            }
            subject.push whois(prefix.nick)
          end
        end
      when STARTED
        puts "here!!"
        if @talk
          if from = @vil.person_by_user(prefix.user)
            if pers.alive?
              case msg
              when /^(?:投票|vote)(?:：|:)(.+?)$/i
                to = @vil.person_by_char($1)
                if from
                  if @vil.set_vote(from, to)
                    notice(prefix.nick, "投票先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                end
              when /^能力(?:：|:)(.+?)$/i
                to = @vil.person_by_char($1)
                if from
                  if @vil.set_prof(from, to)
                    notice(prefix.nick, "能力先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                end
               when /^(?:強襲|襲撃|襲う|襲い)(?:：|:)(.+?)$/i
                to = @vil.person_by_char($1)
                if from.prof == :wolf
                  if @vil.set_prof(from, to)
                    notice(prefix.nick, "襲撃先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                else
                  notice(prefix.nick, "あなたは人狼ではありません。")
                end
              when /^(?:守護|護衛|守り|守る)(?:：|:)(.+?)$/i
                to = @vil.person_by_char($1)
                if from.prof == :guard
                  if @vil.set_prof(from, to)
                    notice(prefix.nick, "護衛先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                else
                  notice(prefix.nick, "あなたは狩人ではありません。")
                end
              when /^(?:預言|占い|占う)(?:：|:)(.+?)$/i
                to = @vil.person_by_char($1)
                if from.prof == :fortune
                  if @vil.set_prof(from, to)
                    notice(prefix.nick, "占い先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                else
                  notice(prefix.nick, "あなたは占い師ではありません。")
                end
              else
                sleep(0.1)
                notice(@mainch, "#{from.char}：#{msg}") 
              end
            end
          end
        end
      end
    else
      if msg =~ /^憑依(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        if $1 =~ /^(on|有り)$/i
          begin
            @profclass = WereWolf::PossessionProfs.new(2)
          rescue
            puts $!, $@
          end
          ans = "有り"
        else
          @profclass = WereWolf::StandardProfs
          ans = "無し"
        end
        notice(@mainch, "憑依を#{ans}に設定しました。")
      elsif msg =~ /^時間(?::|：)(\d+)$/i && @progress < STARTED && @progress > IDLE
        @period = $1.to_i
        notice(@mainch, "制限時間を#{@period}秒に設定しました。")
      elsif msg =~ /^(?:ゲルト|gerd)(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        @gerd = ($1 =~ /^(on|有り)$/i)
        notice(@mainch, "ゲルトを#{if @gerd;"有り";else;"無し";end}に設定しました。")
      elsif msg =~ /^偽音マスタ(?::|：)(.+?)$/i
        case $1
        when /start|開始/i
          @mainch = ch
          @progress = ARRANGE
          notice(@mainch, "偽音マスタを起動します。")
        when /end|finish|終了/i
          if ch == @mainch && @progress > IDLE
            @progress = IDLE
            @villager = []
            @capa = 0
            @date = -1
            @vil = nil
            @t.kill
            notice(@mainch, "偽音マスタを終了します。")
          end
        end
        return
      end
      case @progress
      when ARRANGE
        if msg =~ /^(?:エントリー|entry)(?:開始|start)(?::|：)(.+)$/i
          @capa = $1.to_i
          if @capa >= @capamin && @capa <= @capa
            @progress = WAIT
            notice(@mainch, "#{@capa}人で受け付けます。")
            notice(@mainch, "私に1-1で「エントリー」と発言して下さい。")
            @chars = CHARS.dup
          else
            notice(@mainch, "人数は#{@capamin}人以上#{@capamax}人以下でおねがいします。")
          end
        end
      when WAIT
        if msg =~ /^WW(?:start|スタート)(?::|：)$/i
          if @capamin <= @villager.size
            @progress = STARTED
            @vil = WereWolf::Village.new(@profclass)
            @vil.entry(@nick, "ゲルト", :vil) if @gerd
            kousei = PROFS[@villager.size].dup
            notice(@mainch, "役職割り振り中...")
            @villager.each {|v|
              yaku = kousei.slice!(rand(kousei.size))
              @vil.entry(v[0], v[1], yaku)
              until @whois[v[0]]
              end
              notice(@whois[v[0]], "あなたは#{PNAME[yaku]}です。")
            }
            wolves = @vil.alivers.select{|p| p.prof == :wolf}
            if wolves.size > 1
              wolves.each{|p|
                notice(@whois[p.user], "他の仲間は、#{wolves.dup.delete(p).map!{|a| a.char}.join("と")}です。")
              }
            end
            notice(@mainch, "役職割り振り終了。")
            @t = Thread.new { go }
          else
            notice(@mainch, "規定人数に達していません。")
          end
        end
      when STARTED
      end
    end
  end
  
  def go
    begin
    @vil.start
    w = @vil.profs.prof_prio.shift if @gerd
    @vil.can_vote = false
    result = @vil.update
    @vil.can_vote = true
    @vil.profs.prof_prio.unshift w if @gerd
    notice(@mainch, "1日目...")
    notice(@mainch, "ゲルト：狼なんているわけ無いじゃん。みんな大げさだなああああああああ！") if @gerd
    until @vil.finished?
      @talk = true
      if @period / 60 > 2
        sleep(@period-60)
        notice(@mainch, "残り一分です。能力者・人狼は早急に能力先を決定して下さい！")
        sleep(60)
      else
        sleep(@period)
      end
      @talk = false
      if @vil.progress == 1
        @vil.can_vote = false
        if @gerd
          gerd = @vil.person_by_char("ゲルト")
          @vil.alivers.select{|p| p.prof == :wolf}.each{|p| @vil.set_prof(p, gerd)}
        end
        result = @vil.update
        @vil.can_vote = true
      else
        result = @vil.update
      end

      if result[:hanged]
        result[:votes].each {|k, v|
          notice(@mainch, "#{k.char}は、#{v.char}に投票。")
        }
        notice(@mainch, "結果、#{result[:hanged].char}が処刑された。")
      end
      if r = result[:profs]
        if r[:medium]
          @vil.alivers.select{|p| p.prof == :medium}.each{|p|
            notice(@whois[p.user], "#{result[:hanged]}は#{result[:medium]}だったようだ。")
          }
        end
        if r[:wolf]
          if Array === r[:wolf]
            if r[:wolf][0] == :hyoui
              notice(@whois[r[:wolf][1].user], "あなたは憑依され人狼となりました。")
            end
          else
            notice(@mainch, "次の日、#{r[:wolf].char}が無惨な姿で発見された。")
          end
        else
          notice(@mainch, "今日は犠牲者が居ないようだ。")
        end
        if r[:fortune]
          r[:fortune].each {|k, v|
            notice(@whois[k.user], "#{v[0].char}を占い、#{v[1]}だった。")
          }
        end
        notice(@mainch, "-----")
        notice(@mainch, "#{@vil.progress}日目...")
        notice(@mainch, "本日の生存者は、" + (@vil.alivers.map{|al| al.char}.join("、")) + "の#{@vil.alivers.size}人。")
        
      end
    end
    @progress = IDLE
    notice(@mainch, "==========")
    case result[:winner]
    when :wolf
      notice(@mainch, "全ての村人を退治した……人狼は食糧難になったのだ！")
    when :vil
      notice(@mainch, "全ての人狼を退治した……人狼におびえる日々は去ったのだ！")
    end
    notice(@mainch, "==========")
    @vil.persons.each{|per|
      notice(@mainch, "#{per.char}(#{@whois[per.user]})、#{PNAME[per.prof]}だった。")
    }
    notice(@mainch, "皆さん、お疲れさまでした！")
    @vil = nil
    @villager = []
    rescue
      notice(@mainch, "えらったよ：#{$!}")
      puts $!, $@
    end
  end

  
  def on_rpl_whoisuser(prefix, mynick, nick, user, host, dummy, real)
    @whois[user] = nick
  end
  
  def on_nick(prefix, newnick)
    @whois[prefix.user] = newnick
  end

end

load("const.rb")
ww = WWBot.new(ADDRESS, PORT, NICK, USER, REAL, nil, CHANNELS)
ww.start

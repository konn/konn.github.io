#!/usr/local/bin/ruby
=begin

= IRCB - IRC用Botインターフェース
  
  version: IRCB-2.0.0 2006-04-14T00:10:11+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

require "rice/irc"
require "rice/observer"
require "kconv"

Struct.new("PREFIX", :nick, :user, :server)

module IRCB
  class SimpleBot < RICE::SimpleClient
  attr_reader :subject
  def initialize(server, port, nick, user, real, pass, *channels)
    super(nick, user, real, pass, channels)
    @subject = RICE::Connection.new(server, port)
    @subject.add_observer(self)
    @config = {}
    @real = real
    @nick = nick
    @config[:channels] = channels
    @ctcp = {:VERSION => VERSION}
    bot_initialize if respond_to?(:bot_initialize)
    @pre = Struct::PREFIX
  end
  
  def text2prefix(text)
    prefix = @pre.new
    prefix.nick, prx = text.split("!", 2)
    if prx
      prefix.user, prefix.server = prx.split("@", 2)
    else
      prefix.server = prefix.nick
      prefix.nick = nil
    end
    return prefix
  end
  
  def ctcp_ask(cmd, nick)
    privmsg(nick, "\x01#{cmd.upcase}\x01")
  end
  
  def update(subject, type, message)
    begin
      if message.kind_of?(RICE::Reply::RPL_WELCOME)
        @nick = message.params[0]
      elsif message.kind_of?(RICE::Command::NICK)
        nk = message.prefix.split("!")[0]
        if nk == @nick
          @nick = nk
        end
      end
    rescue
      puts $!, $@
    end
    if !type
      if message.kind_of?(RICE::Command::PING)
        send(:response_for_ping, subject, message)
        return
      elsif message.params[1] =~ /\x01(.+)\x01/
        cmd = $1.upcase
        nicks = message.prefix.split("!")[0]
        case cmd
        when "CLIENTINFO"
          begin
            reply = [@ctcp.keys, :TIME, :CLIENTINFO, :PING].flatten.uniq.join(" ")
          rescue
            puts $!, $@
          end
        when "TIME"
          reply = Time.now.to_s
        when /PING/
          reply = Time.now.to_i
        when /ACTION/i
          return
        else
          reply = @ctcp[cmd.intern]
          unless reply
            subject.push notice(nicks, "\x01ERRMSG unhandled ctcp-command:#{cmd}\x01")
            return
          end
        end
        subject.push notice(nicks, "\x01#{cmd} #{reply}\x01")
        return
      elsif message.kind_of?(RICE::Command::PRIVMSG)
        func = :on_privmsg
      else
        func = 'on_' + message.class.to_s.sub(/^.*::/o, '').downcase
      end
      if respond_to?(func)
        par = message.params.dup.map!{|a| a.toutf8}
        prefix = text2prefix(message.prefix)
        send(func, prefix, *par)
      else
        message(subject, message)
      end
    elsif type == RICE::Connection::ESTABLISHED
      uped(subject, message)
    elsif type == RICE::Connection::CLOSED
      downed(subject, message)
    end
  end
  
  def pass(arg)
    return unless arg
    @subject.push super(arg.tojis)
  end
  
  def user(user, s1, s2, username)
    return unless user && s1 && s2 && username
    @subject.push super(user.tojis, s1.tojis, s2.tojis, username.tojis)
  end
  
  def nick(arg)
    return unless arg
    @subject.push super(arg.tojis)
    @nick = arg
  end
  
  def privmsg(ch, msg)
    return unless ch && msg
    @subject.push super(ch.tojis, msg.tojis)
  end
  
  def notice(ch, msg)
    return unless ch && msg
    @subject.push super(ch.tojis, msg.tojis)
  end
  
  def part(ch, msg="じゃね☆")
    return unless ch
    @subject.push super(ch.tojis, msg.tojis)
  end
  alias part_channel part
  
  def join(arg)
    return unless arg
    @subject.push super(arg.tojis)
  end
  
  def uped(subject, message)
    pass(@pass) if @pass
    nick(@nick)
    user(@user, '0', '*', @username)
  end
  
  def on_rpl_welcome(prefix, mynick, msg)
    @channels.each{|a| join(a)}
  end
  
  def start
    @subject.start
  end
end
  class Client < RICE::SimpleClient
    def initialize(model, subject, nick, user, real, pass, *channels)
      super(nick, user, real, pass, channels)
      @model =  model
      @subject = subject
      @ctcp= {:VERSION => "IRCB Client Ver.0.9 with RICE"}
      @pre = Struct.new("PREFIX", :nick, :user, :prefix)
    end
    
    def update(subject, type, message)
      if !type
        if message.params[1] =~ /\x01(.+)\x01/
          cmd = message.params[1] = $1.upcase
          puts message.params[1]
          STDOUT.flush
          func = :response_for_ctcp
          func1 = :on_ctcp
          case cmd
          when "CLIENTINFO"
            reply = [@ctcp.keys, @model.ctcp.keys, :TIME, :CLIENTINFO, PING].flatten!.uniq!.join(" ")
          when "TIME"
            reply = Time.now.to_s
          when /ACTION/i
            return
          when /PING/
            reply = Time.now.to_i
          else
            ireply = @ctcp[cmd.intern]
            mreply = @model.ctcp[cmd.intern] if @model.config
            reply = mreply || ireply
            unless reply
              return
            end
          end
          
          subject.push notice(message.prefix.split("!")[0], "\x01#{cmd} #{reply}\x01")
          return
        elsif message.kind_of?(RICE::Command::PRIVMSG)
          func = :response_for_privmsg
          func1 = :on_privmsg
        else
          pr = message.class.to_s.sub(/^.*::/o, '').downcase
          func = "response_for_" + pr
          func1 = 'on_' + pr
        end
        
        if @model.respond_to?(func1)
          ch, msg = message.params
          tmp = message.prefix.split("!")
          prefix = @pre.new
          prefix.nick, prefix.user = tmp
          prefix.prefix = tmp.join("!").toutf8
          @model.send(func1, ch.toutf8, prefix, msg.toutf8)
        end
        if respond_to?(func)
          send(func, subject, message)
        else
          message(subject, message)
        end
      elsif type == RICE::Connection::ESTABLISHED
        uped(subject, message)
      elsif type == RICE::Connection::CLOSED
        downed(subject, message)
      end
    end
    
    def response_for_rpl_welcome(subject, message)
      @channels.each {|a|
        subject.push join(a.tojis)
      }
    end
  end
end
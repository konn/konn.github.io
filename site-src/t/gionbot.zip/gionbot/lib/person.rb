=begin

= WereWolf - �ėp�l�T�G���W��
  
  version: WereWolf-3.0.0b2 (2006-04-11T01:39:43+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

module WereWolf
  class Person
    attr_accessor :prof, :alived
    attr_reader :user, :char

    def initialize(user, char, prof)
      @user = user
      @char = char
      @prof = prof
      @alived = true
    end
    
    def kill
      @alived = false
    end
    
    def alive?
      @alived
    end
    
    def dead?
      !@alived
    end

  end
end
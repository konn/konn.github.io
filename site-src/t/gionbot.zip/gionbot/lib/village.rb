=begin

= WereWolf - �ėp�l�T�G���W��
  
  version: WereWolf-3.0.0b2 (2006-04-11T01:39:43+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

require "person.rb"
require "profs.rb"

module WereWolf
  class Village
    attr_accessor :progress, :persons, :hanged, :profs, :can_vote

    def initialize(profs=StandardProfs)
      profs = profs.new if Class === profs
      @profs = profs
      @progress = -1
      @persons = []
      @finished = false
      @votes = Hash.new{|h, k| h[k] = k}
      @can_vote = false
    end
    
    def persons
      @persons
    end
    
    def start
      if @progress == -1
        @progress += 1
        @can_vote = true
      end
    end
    
    def started?
      @progress > -1
    end
    
    def finished?
      @finished
    end
    
    def set_vote(from, to)
      if from.alive? && to.alive?
        @votes[from] = to
        return true
      end
      false
    end
    
    def do_vote
      v = Hash.new(){|h, k| h[k] = 0}
      alivers.each{|al| v[@votes[al]] += 1}
      max = -1
      kouho = []
      v.each{|k, v|
        if v >= max
          if v != max
            kouho = []
            max = v
          end
          kouho.push k 
        end
      }
      
      hanged = kouho[rand(kouho.size)]
      hanged.kill
      @hanged = hanged
      return hanged
    end
    
    def set_prof(from, to)
      result = @profs.set_prof(from, to)
    end
    
    def entry(user, char, prof)
      if @persons.any?{|p| p.user == user || p.char == char}
        return false
      end
      
      @persons.push Person.new(user, char, prof)
      true
    end
    
    def person_by_user(user)
      @persons.find{|pers| pers.user == user}
    end
    
    def person_by_char(char)
      @persons.find{|pers| pers.char == char}
    end
    
    def alivers
      @persons.select{|p| p.alive?}
    end
    
    def update
      return {} if @finished
      if @progress > -1
        voted = do_vote if @can_vote
        results = @profs.use_prof(self)
        ans = {:votes => @votes.dup, :hanged => voted, :winner => nil, :profs => results}
        if winner = @profs.winner(self)
          @finished = true
          ans[:finihed] = true
          ans[:winner] = winner
        end
        @progress += 1
        ans[:finihed] = false
        @votes = Hash.new{|h, k| h[k] = k}
        ans
      end
    end

  end
end
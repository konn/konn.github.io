=begin

= WereWolf - 汎用人狼エンジン
  
  version: WereWolf-3.0.0b2 (2006-04-11T01:39:43+09:00)
  author: konn <konn.jinro@gmail.com>
  HP: http://konn.b7m.net
  

  Ruby's Licence

=end

require "village"

CHAR = %W(パメラ カタリナ リーザ オットー ヴァルター ヨアヒム アルビン ディーター ニコラス トーマス ゲルト ヤコブ ジムゾン ペーター モーリッツ レジーナ)
yaku = [:vil, :fortune, :wolf, :vil, :vil, :lunat, :wolf, :medium, :hamster]
#vil = WereWolf::Village.new
vil = WereWolf::Village.new(WereWolf::HamsterProfs)

0.upto(8) {|i|
  vil.entry(i, i, yaku[i])
}
vil.start

result = {}
  puts "#{vil.progress}日目..."
  puts "生存者："
  vil.alivers.each {|al|
    puts "\t#{CHAR[al.char]}(#{al.prof.inspect})"
  }
  result = vil.update
until vil.finished?
  puts
  puts "#{vil.progress}日目..."
  puts "投票："
  result[:votes].each {|k, v|
    puts "#{CHAR[k.char]}は、#{CHAR[v.char]}に投票。"
  }
  puts "\t\t--> 処刑：#{CHAR[result[:hanged].char]}"
  if r = result[:profs]
    puts "襲撃：#{CHAR[r[:wolf].char]}" if r[:wolf]
    puts "霊能：#{r[:medium]}"
    if r[:fortune]
      r[:fortune].each {|k, v|
        puts "#{CHAR[k.char]}は#{CHAR[v[0].char]}を占い、#{v[1]}だった。"
      }
    end
  end
  puts "生存者："
  vil.alivers.each {|al|
    puts "\t#{CHAR[al.char]}(#{al.prof.inspect})"
  }
  al = vil.alivers
  al.each {|v|
    vil.set_vote(v, al[rand(al.size)])
    vil.set_prof(v, al[rand(al.size)])
  }
  result = vil.update
end
puts
puts "エピローグ..."
puts "投票："
result[:votes].each {|k, v|
  puts "#{CHAR[k.char]}は、#{CHAR[v.char]}に投票。"
}
puts "\t\t--> 処刑：#{CHAR[result[:hanged].char]}"
if r = result[:profs]
  puts "襲撃：#{CHAR[r[:wolf].char]}" if r[:wolf]
end
puts "生存者："
vil.alivers.each {|al|
  puts "\t#{CHAR[al.char]}(#{al.prof.inspect})"
}
puts "====="
puts "#{result[:winner]}の勝利です。"
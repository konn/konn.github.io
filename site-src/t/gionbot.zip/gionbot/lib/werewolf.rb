$LOAD_PATH.push "./lib"
require "person.rb"
require "profs.rb"
require "village.rb"
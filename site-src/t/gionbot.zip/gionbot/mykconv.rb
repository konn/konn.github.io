require "nkf"
class String
  Flag = {
    NKF::UTF8 => "-W", NKF::SJIS => "-S",
    NKF::JIS => "-J", NKF::EUC => "-E"
  }
  
  def tojis
    flag = Flag[NKF.guess(self)]
    NKF.nkf("#{flag} -j", self)
  end
  
  def toutf8
    flag = Flag[NKF.guess(self)]
    NKF.nkf("#{flag} -w8", self)[3..-1]
  end
  
  def toutf8!
    self[0..-1] = toutf8
  end
  
  def tojis!
    self[0..-1] = tojis
  end
end
NICK = "Gion_WW"
USER = "Gion_WW"
REAL = "Jinroh IRC powered by WereWolf."
ADDRESS = "irc.friend.td.nu"
PORT = 6667
PASS = ""
CHANNELS = ['#人狼WW']
CEMETERY = "#人狼墓場"
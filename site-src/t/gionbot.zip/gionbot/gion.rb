require "client.rb"
require "lib/werewolf.rb"
require "thread"

$KCODE = "U"

class WWBot < IRC::Client

  IDLE = -2
  ARRANGE = -1
  WAIT = 0
  STARTED = 1
  ANS = {true => "じんろー", false => "にんげん"}

  CHARS = %W(パメラ カタリナ リーザ オットー ヴァルター ヨアヒム アルビン ディーター ニコラス トーマス  ヤコブ ジムゾン ペーター モーリッツ レジーナ)
  PROFS =  {1 => [:vil], 2 => [:vil, :vil], 3 => [:vil, :vil, :wolf], 
            4 => [:vil, :vil, :wolf, :fortune], 
            5 => [:vil, :vil, :medium, :wolf, :fortune], 
            6 => [:vil, :vil, :medium, :wolf, :wolf, :fortune],
            7 => [:vil, :guard, :meduim, :wolf, :wolf, :fortune, :lunat],
            8 => [:vil, :vil, :guard, :meduim, :wolf, :wolf, :fortune, :lunat],
            9 => [:vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            10 => [:vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            11 => [:vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            12 => [:vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat], 
            13 => [:vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            14 => [:vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            15=>[:vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            16=>[:vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :vil, :guard, :meduim, :wolf, :wolf, :wolf, :fortune, :lunat],
            }
  PNAME = {:vil, "村人", :wolf, "人狼", :medium, "霊能者", :fortune, "占い師", :guard, "狩人", :lunat, "狂人"}
  RYAKU_PNAME = {"人", :vil, "村", :vil, "狼", :wolf, "霊", :medium, "占", :fortune, "狩", :guard, "狂", :lunat, }

  def initialize(chs, *args)
    super(*args)
    @channels = chs
    @hyoui = []
    @first_vote = false
    @progress = IDLE
    @date = -1
    @villager = []
    @whois = {}
    @initialized = true
    @talk = false
    @t = Thread.new{}
    @capa = 16
    @mutex = Mutex.new
    @gerd = true
    @capamax = 16
    @capamin = 3
    @profclass = WereWolf::StandardProfs
    @period = 1
  end

  def on_rpl_namreply(prefix, mynick, nalt, ch, member)
    if ch == CEMETERY
      # mode(ch, "+i")
      member.gsub!("@","")
      member.split(" ").each{|mem|
        kick(ch, mem, "墓は死人の物です") if mem !~ /^(?:mircbot|Oper|#@nick)$/
      }
    end
  end

  def response_for_message(prefix, cmd, args)
    if cmd == "RPL_WELCOME"
      @channels.each{|ch|
        join(ch)
      }
      join(CEMETERY)
      names(CEMETERY)
    end
    fun = "on_#{cmd.downcase}"
    __send__(fun, prefix, *args) if respond_to?(fun)
  end

  def on_privmsg(prefix, ch, msg)
    if ch == @nick
      on_private_chat(prefix,ch,msg)
    else
      if msg =~ /^憑依(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        if $1 =~ /^(on|有り)$/i
          begin
            if @first_vote
              @profclass = WereWolf::PossessionProfs.new(1)
            else
              @profclass = WereWolf::PossessionProfs.new(2)
            end
          rescue
            puts $!, $@
          end
          ans = "有り"
        else
          @profclass = WereWolf::StandardProfs
          ans = "無し"
        end
        notice(@mainch, "憑依を#{ans}に設定しました。")
      elsif msg =~ /^時間(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        @period = $1.to_f
        notice(@mainch, "制限時間を#{@period}分に設定しました。")
      elsif msg =~ /^構成(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        yaku = $1.split("")
        nyaku = yaku.map{|y| RYAKU_PNAME[y]}
        nyaku.compact!
        if nyaku.size == yaku.size
          @yaku = nyaku
          notice(ch, "構成を#{yaku.join(",")}に変更しました。")
        end
      elsif msg =~ /^(?:ゲルト|gerd)(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        @gerd = ($1 =~ /^(on|有り)$/i)
        notice(@mainch, "ゲルトを#{if @gerd;"有り";else;"無し";end}に設定しました。")
      elsif msg =~ /^初日投票(?::|：)(.+)$/i && @progress < STARTED && @progress > IDLE
        if @first_vote = ($1 =~ /^(on|有り)$/i) && WereWolf::PossessionProfs === @profclass
          @profclass = WereWolf::PossessionProfs.new(1)
        end
        notice(@mainch, "初日投票を#{if @first_vote;"有り";else;"無し";end}に設定しました。")
      elsif msg =~ /^偽音マスタ(?::|：)(.+?)$/i
        case $1
        when /start|開始/i
          @mainch = ch
          @progress = ARRANGE
          notice(@mainch, "偽音マスタを起動します。")
        when /end|finish|終了/i
          if ch == @mainch && @progress > IDLE
            @progress = IDLE
            @villager = []
            @capa = 0
            @date = -1
            @vil = nil
            @t.kill
            notice(@mainch, "偽音マスタを終了します。")
          end
        end
        return
      end
      case @progress
      when ARRANGE
        if msg =~ /^(?:エントリー|entry)(?:開始|start)(?::|：)(.+)$/i
          @capa = $1.to_i
          if @capa >= @capamin && @capa <= @capa
            names(CEMETERY)
            @progress = WAIT
            notice(@mainch, "#{@capa}人で受け付けます。")
            notice(@mainch, "私に1-1で「エントリー」と発言して下さい。")
            @chars = CHARS.dup
          else
            notice(@mainch, "人数は#{@capamin}人以上#{@capamax}人以下でおねがいします。")
          end
        end
      when WAIT
        if msg =~ /^WW(?:start|スタート)(?::|：)$/i
          # mode(CEMETERY, "+i")
          if @capamin <= @villager.size
            @progress = STARTED
            @vil = WereWolf::Village.new(@profclass)
            @vil.entry(@nick, "ゲルト", :vil) if @gerd
            kousei = PROFS[@villager.size].dup
            if @yaku
              kousei = @yaku if @yaku.size == @villager.size
            end
            notice(@mainch, "役職割り振り中...")
            @villager.each {|v|
              yaku = kousei.slice!(rand(kousei.size))
              @vil.entry(v[0], v[1], yaku)
              until @whois[v[0]]
              end
              notice(@whois[v[0]], "あなたは#{PNAME[yaku]}です。")
              notice(@whois[v[0]], "能力使用時には、私に1-1で「能力：対象」と発言して下さい。")
            }
            wolves = @vil.alivers.select{|p| p.prof == :wolf}
            if wolves.size > 1
              wolves.each{|per|
                ans = wolves.dup
                ans.delete(per)
                notice(@whois[per.user], "他の仲間は、#{ans.map!{|a| a.char}.join("と")}です。")
              }
            end
            notice(@mainch, "役職割り振り終了。")
            @t = Thread.new { go }
          else
            notice(@mainch, "規定人数に達していません。")
          end
        end
      when STARTED
      end
    end
  end

  def on_private_chat(prefix, ch, msg)
    case @progress
    when WAIT
      if msg =~ /^(entry|(?:エントリ|えんとり)(?:ー)?|suntry|サントリー|さんとりー)$/i
        user = prefix.user
        unless @villager.any?{|a| a[0] == user}
          @mutex.synchronize {
            unless @villager.size >= @capa
              char = @chars.slice!(rand(@chars.size))
              @villager.push [user, char]
              notice(prefix.nick, "エントリー受け付けました。あなたは#{char}です。")
              notice(@mainch, "#{char}がエントリーしました。残り#{@capa - @villager.size}人です。")
            end
          }
          whois(prefix.nick)
        end
      end
    when STARTED
      if @talk
        if from = @vil.person_by_user(prefix.user)
          if from.alive?
            case msg
            when /^(?:投票|vote)(?:：|:)(.+?)$/i
              if @vil.can_vote
                to = @vil.person_by_char($1)
                if to
                  if @vil.set_vote(from, to)
                    notice(prefix.nick, "投票先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                end
              else
                notice(prefix.nick, "今日は投票はありません。")
              end
            when /^能力(?:：|:)(.+?)$/i
              to = @vil.person_by_char($1)
              if from
                if @vil.profs.prof_prio.include?(from.prof)
                  if @vil.set_prof(from, to)
                    notice(prefix.nick, "能力先を#{$1}に変更しました。")
                  else
                    notice(prefix.nick, "そんなキャラ居ません :-0")
                  end
                else
                  notice(prefix.nick, "今あなたは能力を使用できません。")
                end
              end
             when /^(?:強襲|襲撃|襲う|襲い|喰う|喰い|食う|食い)(?:：|:)(.+?)$/i
              to = @vil.person_by_char($1)
              if from.prof == :wolf
                if @vil.set_prof(from, to)
                  notice(prefix.nick, "襲撃先を#{$1}に変更しました。")
                else
                  notice(prefix.nick, "そんなキャラ居ません :-0")
                end
              else
                notice(prefix.nick, "あなたは人狼ではありません。")
              end
            when /^(?:守護|護衛|守り|守る)(?:：|:)(.+?)$/i
              to = @vil.person_by_char($1)
              if from.prof == :guard
                if @vil.set_prof(from, to)
                  notice(prefix.nick, "護衛先を#{$1}に変更しました。")
                else
                  notice(prefix.nick, "そんなキャラ居ません :-0")
                end
              else
                notice(prefix.nick, "あなたは狩人ではありません。")
              end
            when /^(?:預言|占い|占う)(?:：|:)(.+?)$/i
              to = @vil.person_by_char($1)
              if from.prof == :fortune
                if @vil.set_prof(from, to)
                  notice(prefix.nick, "占い先を#{$1}に変更しました。")
                else
                  notice(prefix.nick, "そんなキャラ居ません :-0")
                end
              else
                notice(prefix.nick, "あなたは占い師ではありません。")
              end
            else
              sleep(0.2)
              notice(@mainch, "#{from.char}：#{msg}") 
            end
          end
        end
      end
    end
  end

  def go
    begin
    @vil.start
    w =  @vil.profs.prof_prio.slice!(-2) if @gerd
    @vil.can_vote = false
    result = @vil.update
    @vil.can_vote = true
    @vil.profs.prof_prio.insert(-1,w) if @gerd
    notice(@mainch, "1日目...")
    notice(@mainch, "ゲルト：ゲルトなんているわけ無いじゃん。みんな大げさだなああああああああ！") if @gerd
    until @vil.finished?
      @talk = true
      if @period >= 2
        sleep(@period*60-60)
        notice(@mainch, "残り一分です。能力者・人狼は早急に能力先を決定して下さい！")
        @vil.alivers.each{|p|
          if p.prof != :vil
            sleep(0.2)
            notice(@whois[p.user], "あと一分です。能力を使用して下さい。")
          end
        }
        sleep(60)
      else
        sleep(@period * 60)
      end
      @talk = false

      if @vil.progress == 1
        @vil.can_vote = false unless @first_vote
        if @gerd
          gerd = @vil.person_by_char("ゲルト")
          @vil.alivers.select{|p| p.prof == :wolf}.each{|p| @vil.set_prof(p, gerd)}
        end
        result = @vil.update
        @vil.can_vote = true
      else
        result = @vil.update
      end
      if result[:hanged]
        result[:votes].each {|k, v|
          sleep(0.5)
          notice(@mainch, "#{k.char}は、#{v.char}に投票。")
        }
        sleep(1)
        notice(@mainch, "結果、#{result[:hanged].char}が処刑された。")
        nick = @whois[result[:hanged].user]
        sleep(0.5)
        invite(nick, CEMETERY)
        sleep(0.5)
        notice(nick, "あなたは吊りコロされたので #人狼墓場 でおとなしくしててください。")
      end
      if r = result[:profs]
        unless r[:medium].nil?
          @vil.alivers.select{|p| p.prof == :medium}.each{|p|
            sleep(1)
            notice(@whois[p.user], "#{result[:hanged].char}は#{ANS[r[:medium]]}だったということらしい。")
          }
        end
        if r[:wolf]
          if Array === r[:wolf]
            puts "hoge"
            if r[:wolf][0] == :hyoui
              puts "rahmen"
              sleep(1)
              notice(@whois[r[:wolf][1].user], "ひょーいされたよ。うっひょーい！")
              notice(@mainch, "今日は犠牲者が居ないようだ。")
              @hyoui = [r[:wolf][1], r[:wolf][-1]]
              wolves = @vil.alivers.select{|p| p.prof == :wolf}
              if wolves.size > 1
                wolves.each{|p|
                  if p == r[:wolf][1]
                    sleep(0.5)
                    notice(@whois[p.user], "他の仲間は、#{wolves.dup.delete(p).map!{|a| a.char}.join("と")}です。")
                  else
                    sleep(0.5)
                    notice(@whois[p.user], "#{r[:wolf].char}が憑依され仲間になりました。")
                  end
                }
              end
            end
          else
            sleep(1)
            notice(@mainch, "--------")
            sleep(0.5)
            notice(@mainch, "次の日、#{r[:wolf].char}が無惨な姿で発見された。")
             if attacked = r[:wolf]
              nick = @whois[r[:wolf].user]
              invite(nick, CEMETERY)
              sleep 0.5
              notice(nick, "あなたは目出度く人狼の食料になりました。#人狼墓場 で栄光をかみしめて下さい。")
            end
          end
        else
          sleep 0.5
          notice(@mainch, "今日は犠牲者が居ないようだ。")
        end
        if r[:fortune]
          r[:fortune].each {|k, v|
            notice(@whois[k.user], "#{v[0].char}は#{ANS[v[1]]}らしーけど。")
          }
        end
        sleep(1)
        notice(@mainch, "-----")
        notice(@mainch, "#{@vil.progress}日目...")
        sleep(1)
        notice(@mainch, "本日の生存者は、" + (@vil.alivers.map{|al| al.char}.join("、")) + "の#{@vil.alivers.size}人。")
        sleep(1)
      end
    end
    @progress = IDLE
    notice(@mainch, "==========")
    case result[:winner]
    when :wolf
      notice(@mainch, "全ての村人を退治した……人狼は食糧難になったのだ！")
    when :vil
      notice(@mainch, "全ての人狼を退治した……人狼におびえる日々は去ったのだ！")
    end
    notice(@mainch, "==========")
    @vil.persons.each{|per|
      sleep(0.5)
      if per == @hyoui[0]
        notice(@mainch, "#{per.char}(#{@whois[per.user]})、#{PNAME[@hyoui[1]]}だった。憑依され人狼となった。")
      else
        notice(@mainch, "#{per.char}(#{@whois[per.user]})、#{PNAME[per.prof]}だった。")
      end
    }
    notice(@mainch, "皆さん、お疲れさまでした！")
    # mode(CEMETERY, "-i")
    @vil = nil
    @villager = []
    rescue
      notice(@mainch, "えらったよ：#{$!}")
      puts $!, $@
    end
  end

  def on_rpl_whoisuser(prefix, mynick, nick, user, host, dummy, real)
    @whois[user] = nick
  end

  def on_nick(prefix, newnick)
    @whois[prefix.user] = newnick
  end

end

load("const.rb")
ww = WWBot.new(CHANNELS, ADDRESS, PORT, PASS, NICK, USER, REAL)
begin
  ww.start
rescue
  puts $!, $!.backtrace
end
require "socket"
require "message.rb"
require "prefix.rb"
require "mykconv"

module IRC
  
  class Client
    include Message
  
    def initialize(server, port, pass, nick, user, real)
      @server = server
      @port = port
      @pass = pass
      @pass = "dummy" if @pass.empty?
      @user = user
      @nick = nick
      @real = real
      init
    end
  
    def init
      # overriden by sub-classes
    end
  
    def start
      @socket = TCPSocket.new(@server, @port)
      send_message("PASS", @pass) unless @pass.empty?
      send_message("NICK", @nick)
      send_message("USER", @user, 0, '*', @real)
      while msg = @socket.gets
        msg = msg.toutf8
        prfx = nil
        cmd = ""
        tmp = []
        if msg[0] == ?:
          prfx, cmd, *tmp = msg[1..-1].split(" ")
        else
          cmd, *tmp = msg.split(" ")
        end
        args = []
        eoc = false
        tmp.each_with_index{|ar,ind|
          if eoc
            args[-1] += " " + ar
          else
            if ar[0] == ?:
              eoc = true
              ar = ar[1..-1]
            end
            args << ar
          end
        }
        cmd = resolve_rpl(cmd)
        prfx = Prefix.new(prfx)
        if cmd == "PING"
          send_message("PONG", *args)
        elsif cmd == "NICK" && prfx.nick == @nick && prfx.user == @user
          @nick = args[0]
        end
        response_for_message(prfx, cmd, args)
      end
    end
  
    def close(quitmsg="Quit!")
      send_message("QUIT", quitmsg)
      #@t.kill
    end
  
    def response_for_message(prfx, cmd, args)
      puts ">> :#{prfx.inspect} #{cmd} #{args.join(' ')}"
    end
  
    def send_message(cmd, *args)
      args.map!{|a| a.to_s.tojis}
      args[-1] = ':' + args[-1] if args[-1] =~ /\s/
      msg = cmd + ' ' + args.join(' ')
      @socket.puts msg
      @socket.puts
    end

  end

end
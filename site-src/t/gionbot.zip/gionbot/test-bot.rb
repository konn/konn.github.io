require "client"

MAINCH = "#WWTEST"
GION = "Gion_WW"

class HogeClient < IRC::Client

  def initialize(hoge, *arg)
    super *arg
    @hoge = hoge;
  end

  def response_for_message(prefix, cmd, args)
    if cmd == "RPL_WELCOME"
      join(MAINCH)
    end
    fun = "on_#{cmd.downcase}"
    __send__(fun, prefix, *args) if respond_to?(fun)
  end

  def on_invite(prefix, mynick, ch)
    notice(MAINCH, "invited to #{ch} / join.")
    join(ch)
  end

  def on_notice(prefix, ch, msg)
    sleep(@hoge)
    
    if msg == "私に1-1で「エントリー」と発言して下さい。"
      privmsg(GION, "suntry")
    elsif ch == MAINCH
      return
    elsif msg =~ /あなたは.+です/
      privmsg(GION, msg)
    else
      notice(MAINCH, "#{@nick} -- #{msg}")
    end
  end

  def on_privmsg(prefix, ch, msg)
    sleep(@hoge)
    if msg =~ /^(?:エントリー|entry)(?:開始|start)(?::|：)(.+)$/i
     # privmsg(GION, "suntry")
    elsif msg =~ /^(投票：.+)/
      privmsg(GION, msg)
    elsif msg =~ /^(襲撃：.+)/
      privmsg(GION, msg)
    end
  end

end

t = []
jogen = ARGV.shift.to_i
jogen.times {|i|
  t << Thread.new{
    hc = HogeClient.new(i,"irc.friend.td.nu", 6664, "", "konn#{i}", "konn#{i}", "testing bot")
    hc.start
    if i < jogen-1
      Thread.pass
    else
      loop{}
    end
  }
}

sleep
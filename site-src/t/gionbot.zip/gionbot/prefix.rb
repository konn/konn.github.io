module IRC

  class Prefix
    attr_reader :nick, :user, :server

    def initialize(text)
      return nil unless text
      a, b = text.split("!")
      unless b
        hoge = a.split(".")
        if hoge.size > 0
          @server = a
        else
          @nick = a
        end
      else
        @nick = a
        @user, @server = b.split("@")
      end
    end

    def inspect
      if nick
        [@nick, [@user, @server].compact.join("@") ].compact.join("!")
      else
        @server
      end
    end

  end

end
//
//  AppDelegate.m
//  CurrencyConverter
//
//  Created by 石井 大海 on 2014/12/10.
//  Copyright (c) 2014年 My Name. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (IBAction)convert:(id)sender {
}
@end

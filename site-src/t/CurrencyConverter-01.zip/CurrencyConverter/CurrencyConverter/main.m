//
//  main.m
//  CurrencyConverter
//
//  Created by 石井 大海 on 2014/12/10.
//  Copyright (c) 2014年 My Name. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}

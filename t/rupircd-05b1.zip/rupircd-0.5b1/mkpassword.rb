require "digest/md5"

p Digest::MD5.hexdigest(ARGV.shift)